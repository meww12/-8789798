﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ListClass.Classes;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 
        List<Pharmacy> pharmacies = new List<Pharmacy>();
        public MainWindow()
        {
            InitializeComponent();
            pharmacies.Add(new Pharmacy("Цитрамон", 100, 199.90, 36));
            pharmacies.Add(new Pharmacy("Парацетамол", 200, 279.90, 24));
            pharmacies.Add(new Pharmacy("Нурофен", 255, 356.90, 24));
            pharmacies.Add(new Pharmacy("Спазган", 99, 555.01, 36));
            pharmacies.Add(new Pharmacy("Витамин C", 1000, 50.00, 12));
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListPreparate.ItemsSource = pharmacies;
        }
        /// <summary>
        /// сортировка по алфавиту
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListPreparate.ItemsSource = pharmacies.OrderBy(x=>x.NamePreparate);
        }
        /// <summary>
        /// сортировка в обратном порядке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListPreparate.ItemsSource = pharmacies.OrderByDescending(x => x.NamePreparate);
        }
        /// <summary>
        /// поиск по названию
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            DtgListPreparate.ItemsSource = pharmacies.Where(x => x.NamePreparate.Contains(TxtSearch.Text));
        }
    }
}
